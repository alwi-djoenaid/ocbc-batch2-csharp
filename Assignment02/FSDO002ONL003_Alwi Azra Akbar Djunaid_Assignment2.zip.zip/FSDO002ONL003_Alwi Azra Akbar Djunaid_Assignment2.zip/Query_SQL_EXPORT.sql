
-- Tabel productLines
CREATE TABLE product_lines(
	product_line VARCHAR(6) PRIMARY KEY,
	text_description VARCHAR(70) NULL,
	html_description VARCHAR(MAX) NULL,
	product_image VARCHAR(MAX) NULL
);

INSERT INTO product_lines VALUES
	('PL001', 'Ini barang nomor satu', 'Ini html description nomor satu', 'image nomor satu'),
	('PL002', 'Ini barang nomor dua', 'Ini html description nomor dua', 'image nomor dua'),
	('PL003', 'Ini barang nomor tiga', 'Ini html description nomor tiga', 'image nomor tiga'),
	('PL004', 'Ini barang nomor empat', 'Ini html description nomor empat', 'image nomor empat'),
	('PL005', 'Ini barang nomor lima', 'Ini html description nomor lima', 'image nomor lima');

INSERT INTO product_lines VALUES
	('PL006', 'Ini barang nomor enam', 'Ini html description nomor enam', 'image nomor enam'),
	('PL007', 'Ini barang nomor tujuh', 'Ini html description nomor tujuh', 'image nomor tujuh'),
	('PL008', 'Ini barang nomor delapan', 'Ini html description nomor delapan', 'image nomor delapan'),
	('PL009', 'Ini barang nomor sembilan', 'Ini html description nomor sembilan', 'image nomor sembilan'),
	('PL010', 'Ini barang nomor sepuluh', 'Ini html description nomor sepuluh', 'image nomor sepuluh');

SELECT * FROM product_lines;


-- Tabel products
CREATE TABLE products(
	product_code VARCHAR(6) PRIMARY KEY,
	product_name VARCHAR(MAX) NOT NULL,
	product_line VARCHAR(6) FOREIGN KEY REFERENCES product_lines(product_line),
	product_scale VARCHAR(25) NULL,
	product_vendor VARCHAR(50) NULL,
	product_description VARCHAR(MAX) NULL,
	quantity_in_stock INT NULL,
	buy_price INT NULL,
	msrp INT NULL
);

INSERT INTO products VALUES
	('PD0001', 'Product 1', 'PL001', 'Kilogram', 'PT X', 'Ini produk 1', 300, 15000, 25000),
	('PD0002', 'Product 2', 'PL001', 'Liter', 'PT Y', 'Ini produk 2', 100, 35000, 50000),
	('PD0003', 'Product 3', 'PL001', 'Meter', 'PT Z', 'Ini produk 3', 500, 7500, 10000),
	('PD0004', 'Product 4', 'PL002', 'Gram', 'PT Suka Sejahtera', 'Ini produk 4', 150, 50000, 70000),
	('PD0005', 'Product 5', 'PL003', 'Kilogram', 'PT Bolay Sejahtera', 'Ini produk 5', 50, 70000, 100000),
	('PD0006', 'Product 6', 'PL004', 'Kilogram', 'PT Sejahtera', 'Ini produk 6', 75, 60000, 75000),
	('PD0007', 'Product 7', 'PL004', 'Meter', 'PT A', 'Ini produk 7', 60, 64000, 71000),
	('PD0008', 'Product 8', 'PL005', 'Gram', 'PT D', 'Ini produk 8', 40, 76000, 81000),
	('PD0009', 'Product 9', 'PL005', 'Kilogram', 'PT Ben Makmur', 'Ini produk 9', 870, 1500, 3200),
	('PD0010', 'Product 10', 'PL009', 'Liter', 'PT X', 'Ini produk 10', 510, 3700, 6200);

SELECT * FROM product_lines pl JOIN products p ON p.product_line = pl.product_line


-- Tabel orderDetails
CREATE TABLE order_details(
	order_number VARCHAR(7) NOT NULL,
	product_code VARCHAR(6) FOREIGN KEY REFERENCES products(product_code),
	quantity_ordered int NOT NULL,
	orderline_number int NULL
);

ALTER TABLE order_details ALTER COLUMN product_code VARCHAR(6) NOT NULL;
ALTER TABLE order_details ADD PRIMARY KEY (order_number, product_code);
ALTER TABLE order_details ADD CONSTRAINT fk_order_number FOREIGN KEY (order_number) REFERENCES orders(order_number);

INSERT INTO order_details VALUES
	('OR001', 'PD0010', 80, 1),
	('OR002', 'PD0007', 10, 2),
	('OR003', 'PD0001', 85, 3),
	('OR004', 'PD0005', 77, 4),
	('OR005', 'PD0004', 19, 5),
	('OR006', 'PD0006', 21, 6),
	('OR007', 'PD0008', 46, 7),
	('OR008', 'PD0002', 67, 8),
	('OR009', 'PD0003', 91, 9),
	('OR010', 'PD0009', 42, 10);

SELECT * FROM order_details;

-- Tabel orders
CREATE TABLE orders(
	order_number VARCHAR(7) PRIMARY KEY,
	order_date DATE NOT NULL,
	required_date DATE NOT NULL,
	shipped_date DATE NOT NULL,
	order_status VARCHAR(15) NOT NULL,
	comments VARCHAR(MAX) NULL,
	customer_number VARCHAR(10) NOT NULL
);

ALTER TABLE orders ADD CONSTRAINT fk_customer_number FOREIGN KEY (customer_number) REFERENCES customers(customer_number);

INSERT INTO orders VALUES
	('OR001', '2021-11-22', '2021-11-25', '2021-11-24', 'Delivered', 'Barang sudah sampai', 'CS001'),
	('OR002', '2021-11-23', '2021-11-26', '2021-11-25', 'Delivered', 'Barang sudah sampai', 'CS002'),
	('OR003', '2021-11-24', '2021-11-27', '2021-11-26', 'Delivered', 'Barang sudah sampai', 'CS003'),
	('OR004', '2021-11-25', '2021-11-28', '2021-11-27', 'Delivered', 'Barang sudah sampai', 'CS004'),
	('OR005', '2021-11-26', '2021-11-29', '2021-11-28', 'Delivered', 'Barang sudah sampai', 'CS005'),
	('OR006', '2021-11-27', '2021-11-30', '2021-11-29', 'Delivered', 'Barang sudah sampai', 'CS006'),
	('OR007', '2021-11-28', '2021-12-01', '2021-11-30', 'Delivered', 'Barang sudah sampai', 'CS007'),
	('OR008', '2021-11-29', '2021-12-02', '2021-12-01', 'Delivered', 'Barang sudah sampai', 'CS008'),
	('OR009', '2021-11-30', '2021-12-03', '2021-12-02', 'Delivered', 'Barang sudah sampai', 'CS009'),
	('OR010', '2021-12-01', '2021-12-04', '2021-12-03', 'Delivered', 'Barang sudah sampai', 'CS010');

SELECT * FROM orders


-- Tabel customers
CREATE TABLE customers(
	customer_number VARCHAR(10) PRIMARY KEY NOT NULL,
	customer_name VARCHAR(75) NOT NULL,
	contact_lastname VARCHAR(15) NULL,
	contact_firstname VARCHAR(15) NOT NULL,
	phone VARCHAR(16) NOT NULL,
	address_line1 VARCHAR(MAX) NOT NULL,
	address_line2 VARCHAR(MAX) NULL,
	city VARCHAR(20) NULL,
	state_address VARCHAR(30) NULL,
	postal_code VARCHAR(9) NOT NULL,
	country VARCHAR(50) NOT NULL,
	salesrep_employeenumber VARCHAR(7) NOT NULL,
	credit_limit INT
);

ALTER TABLE customers ADD CONSTRAINT fk_salesrep_employee FOREIGN KEY (salesrep_employeenumber) REFERENCES employees(employee_number);

INSERT INTO customers VALUES
	('CS001', 'Daffa', 'Tuti', 'Moko', '0192471827', 'Jl. Bije', 'Jl. Sakinah', 'Jakarta Pusat', 'DKI Jakarta', '14045', 'Indonesia', 'EM001', 10000000),
	('CS002', 'Mikazuki', 'Augus', 'Mikazuki', '0192103974', 'Jl. Jibi', 'Jl. Margonda', 'Jakarta Selatan', 'DKI Jakarta', '14045', 'Indonesia', 'EM006', 7500000),
	('CS003', 'Athrun', 'Zala', 'Athrun', '0192023874', 'Jl. Margonda Raya', 'Jl. Sudirman', 'Jakarta Barat', 'DKI Jakarta', '14045', 'Indonesia', 'EM007', 7600000),
	('CS004', 'Kira', 'Yamato', 'Kira', '0192984502', 'Jl. Kuningan', 'Jl. Kasablanka', 'Jakarta Timur', 'DKI Jakarta', '14045', 'Indonesia', 'EM006', 1400000),
	('CS005', 'Amuro', 'Ray', 'Amuro', '0192921013', 'Jl. Sarinah', 'Jl. Thamrin', 'Jakarta Utara', 'DKI Jakarta', '14045', 'Indonesia', 'EM006', 6250000),
	('CS006', 'Sasuke', 'Uchiha', 'Sasuke', '0192928301', 'Jl. SCBD', 'Jl. Senayan', 'Kota Depok', 'Jawa Barat', '14045', 'Indonesia', 'EM010', 1090210),
	('CS007', 'Naruto', 'Uzumaki', 'Naruto', '0192782931', 'Jl. Fatmawati', 'Jl. Antasari', 'Cinere', 'Jawa Barat', '14045', 'Indonesia', 'EM007', 14000000),
	('CS008', 'Putra', 'Putri', 'Moko', '0192102838', 'Jl. Pondok Indah', 'Jl. Panglima Polim', 'Tangerang Selatan', 'Tangerang', '14045', 'Indonesia', 'EM010', 2520000),
	('CS009', 'Bolay', 'Kape', 'Akep', '0192903817', 'Jl. Ampera', 'Jl. Kemang', 'Alam Sutera', 'Tangerang', '14045', 'Indonesia', 'EM002', 2240000),
	('CS010', 'Ocan', 'Farid', 'Boy', '0192283950', 'Jl. Coar', 'Jl. Rajawali', 'Kota Depok', 'Jawa Barat', '14045', 'Indonesia', 'EM005', 8750000);

SELECT * FROM customers;


-- Tabel payment
CREATE TABLE payments(
	customer_number VARCHAR(10) NOT NULL,
	check_number VARCHAR(10) NOT NULL,
	payment_date DATE NOT NULL,
	amount int NOT NULL
);

ALTER TABLE payments ADD PRIMARY KEY(customer_number, check_number);
ALTER TABLE payments ADD CONSTRAINT fk_customer_number_payment FOREIGN KEY (customer_number) REFERENCES customers(customer_number);

INSERT INTO payments VALUES
	('CS001', 'CH001', '2021-11-22', 10000000),
	('CS002', 'CH002', '2021-11-23', 7500000),
	('CS003', 'CH003', '2021-11-24', 7600000),
	('CS004', 'CH004', '2021-11-25', 1400000),
	('CS005', 'CH005', '2021-11-26', 6250000),
	('CS006', 'CH006', '2021-11-27', 1090210),
	('CS007', 'CH007', '2021-11-28', 14000000),
	('CS008', 'CH008', '2021-11-29', 2520000),
	('CS009', 'CH009', '2021-11-30', 2240000),
	('CS010', 'CH010', '2021-12-01', 8750000);

SELECT * FROM payments;


-- Tabel employees
CREATE TABLE employees(
	employee_number VARCHAR(7) PRIMARY KEY NOT NULL,
	last_name VARCHAR(15) NOT NULL,
	first_name VARCHAR(40) NOT NULL,
	extension VARCHAR(10) NOT NULL,
	office_code VARCHAR(10) NOT NULL,
	reports_to VARCHAR(7) NOT NULL,
	job_title VARCHAR(80) NOT NULL
);

ALTER TABLE employees ADD CONSTRAINT fk_employee_number FOREIGN KEY (reports_to) REFERENCES employees(employee_number);
ALTER TABLE employees ADD CONSTRAINT fk_office_number FOREIGN KEY (office_code) REFERENCES offices(office_code);

INSERT INTO employees VALUES
('EM001', 'Ajri', 'Aji', '1234567890', 'OF002', 'EM001', 'CEO'),
	('EM002', 'Ho', 'Bobo', '0987654321', 'OF001', 'EM002', 'CTO'),
	('EM003', 'Suke', 'Kesu', '6789012345', 'OF003', 'EM003', 'CTO'),
	('EM004', 'Uzumaki', 'Naruto', '5432109876', 'OF001', 'EM001', 'Supervisor'),
	('EM005', 'Sasuke', 'Uchiha', '1234509876', 'OF002', 'EM001', 'Supervisor'),
	('EM006', 'Saku', 'Judy', '5432167890', 'OF002', 'EM003', 'Store Manager'),
	('EM007', 'Saku', 'Jody', '1324354657', 'OF004', 'EM002', 'Store Manager'),
	('EM008', 'Tuti', 'Moko', '0192837465', 'OF005', 'EM002', 'Sales'),
	('EM009', 'Farid', 'Ocan', '5647382910', 'OF003', 'EM003', 'Sales'),
	('EM010', 'Daffa', 'Boy', '0912873465', 'OF007', 'EM001', 'Sales');

SELECT * FROM employees;

-- Tabel offices
CREATE TABLE offices(
	office_code VARCHAR(10) PRIMARY KEY NOT NULL,
	city VARCHAR(30) NOT NULL,
	phone VARCHAR(16) NOT NULL,
	address_line1 VARCHAR(MAX) NOT NULL,
	address_line2 VARCHAR(MAX) NULL,
	state_address VARCHAR(30) NULL,
	postal_code VARCHAR(9) NOT NULL,
	country VARCHAR(50) NOT NULL,
	territory VARCHAR(50) NOT NULL
);

INSERT INTO offices VALUES
	('OF001', 'Depok', '081238375713', 'Jl. Arco', 'Jl. Sawangan', 'Jawa Barat', '14045', 'Indonesia', 'Sawangan komplek Arco'),
	('OF002', 'Depok', '081218276043', 'Jl. Ocra', 'Jl. Rajawali', 'Jawa Barat', '14045', 'Indonesia', 'Perumahan Bolai'),
	('OF003', 'Jakarta Selatan', '081290375631', 'Jl. Arco', 'Jl. Sawangan', 'DKI Jakarta', '14045', 'Indonesia', 'Sawangan komplek Arco'),
	('OF004', 'Jakarta Barat', '081238570193', 'Jl. Kebon Jeruk', 'Jl. Jeruk Kebon', 'DKI Jakarta', '14045', 'Indonesia', 'Lawson Kebon Jeruk'),
	('OF005', 'Jakarta Utara', '081248390185', 'Jl. Rusa', 'Jl. Kijang', 'DKI Jakarta', '14045', 'Indonesia', 'Indomaret Kijang'),
	('OF006', 'Jakarta Timur', '081210290565', 'Jl. Syahdan', 'Jl. Syah Dan', 'DKI Jakarta', '14045', 'Indonesia', 'Sawangan komplek Arco'),
	('OF007', 'Jakarta Pusat', '081237582753', 'Jl. Telaga Golf', 'Jl. Golf Telaga', 'DKI Jakarta', '14045', 'Indonesia', 'Indomaret Telaga Golf'),
	('OF008', 'Tangerang Selatan', '081209282851', 'Jl. Aeon', 'Jl. Ice', 'Tangerang', '14045', 'Indonesia', 'BSD City'),
	('OF009', 'Tangerang Selatan', '081201298743', 'Jl. QBig', 'Jl. The Breeze', 'Tangerang', '14045', 'Indonesia', 'Alam Sutera'),
	('OF010', 'Jakarta Selatan', '081242093874', 'Jl. Pondok Indah', 'Jl. Arteri Pondok Indah', 'DKI Jakarta', '14045', 'Indonesia', 'PIM 2');

SELECT * FROM offices